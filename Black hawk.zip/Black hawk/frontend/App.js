import React, { useState, useEffect, useRef } from 'react';
import { io } from 'socket.io-client';
import Peer from 'simple-peer';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import { BrowserRouter as Router, Route, Switch, Link } from 'react-router-dom';

const socket = io('http://localhost:5000');

// App Component
function App() {
  return (
    <Router>
      <div className="container">
        <h1 className="text-center mt-4">Black Hawk</h1>
        <nav className="navbar navbar-expand-lg navbar-light bg-light">
          <Link className="navbar-brand" to="/">Home</Link>
          <div className="collapse navbar-collapse">
            <ul className="navbar-nav mr-auto">
              <li className="nav-item">
                <Link className="nav-link" to="/profile">Profile</Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link" to="/friends">Friends</Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link" to="/chat">Chat</Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link" to="/video-call">Video Call</Link>
              </li>
            </ul>
          </div>
        </nav>
        <Switch>
          <Route path="/profile" component={Profile} />
          <Route path="/friends" component={Friends} />
          <Route path="/chat" component={Chat} />
          <Route path="/video-call" component={VideoCall} />
          <Route path="/" exact component={Home} />
        </Switch>
      </div>
    </Router>
  );
}

// Home Component
function Home() {
  return (
    <div className="text-center mt-4">
      <h2>Welcome to Black Hawk</h2>
      <p>Connect with friends, chat, and video call seamlessly.</p>
    </div>
  );
}

// Profile Component for user profile management
function Profile() {
  const [profilePic, setProfilePic] = useState(null);

  const handleProfilePictureChange = (e) => {
    const file = e.target.files[0];
    setProfilePic(URL.createObjectURL(file));
  };

  return (
    <div className="mt-4">
      <h3>Profile Settings</h3>
      <div className="form-group">
        <label htmlFor="profilePic">Profile Picture</label>
        <input type="file" className="form-control-file" id="profilePic" onChange={handleProfilePictureChange} />
        {profilePic && <img src={profilePic} alt="Profile" className="img-fluid rounded mt-3" width="150" />}
      </div>
    </div>
  );
}

// Friends Component for searching and sending friend requests
function Friends() {
  const [searchQuery, setSearchQuery] = useState('');
  const [users, setUsers] = useState([]);

  const handleSearch = (e) => {
    e.preventDefault();
    // Fetch the users with the search query
    socket.emit('searchUsers', searchQuery);
  };

  useEffect(() => {
    socket.on('usersFound', (users) => {
      setUsers(users);
    });
  }, []);

  const sendFriendRequest = (userId) => {
    socket.emit('sendFriendRequest', userId);
  };

  return (
    <div className="mt-4">
      <h3>Find Friends</h3>
      <form onSubmit={handleSearch}>
        <div className="form-group">
          <input
            type="text"
            className="form-control"
            placeholder="Search by name"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <button type="submit" className="btn btn-primary">Search</button>
      </form>
      <ul className="list-group mt-3">
        {users.map((user) => (
          <li key={user.id} className="list-group-item">
            {user.name}
            <button className="btn btn-success float-right" onClick={() => sendFriendRequest(user.id)}>
              Send Friend Request
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}

// Chat Component for messaging
function Chat() {
  const [messages, setMessages] = useState([]);
  const [message, setMessage] = useState('');
  const messageRef = useRef();

  useEffect(() => {
    socket.on('message', (msg) => {
      setMessages((prevMessages) => [...prevMessages, msg]);
    });
  }, []);

  const sendMessage = () => {
    socket.emit('sendMessage', message);
    setMessage('');
  };

  return (
    <div className="mt-4">
      <h3>Chat</h3>
      <div className="chat-box">
        {messages.map((msg, index) => (
          <div key={index} className="message">
            {msg}
          </div>
        ))}
      </div>
      <div className="input-group mt-3">
        <input
          type="text"
          className="form-control"
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          ref={messageRef}
        />
        <div className="input-group-append">
          <button className="btn btn-primary" onClick={sendMessage}>Send</button>
        </div>
      </div>
    </div>
  );
}

// VideoCall Component for handling video calls
function VideoCall() {
  const [me, setMe] = useState('');
  const [stream, setStream] = useState();
  const [receivingCall, setReceivingCall] = useState(false);
  const [caller, setCaller] = useState('');
  const [callerSignal, setCallerSignal] = useState();
  const [callAccepted, setCallAccepted] = useState(false);
  const [idToCall, setIdToCall] = useState('');
  const [callEnded, setCallEnded] = useState(false);
  const [name, setName] = useState('');
  const myVideo = useRef();
  const userVideo = useRef();
  const connectionRef = useRef();

  useEffect(() => {
    navigator.mediaDevices.getUserMedia({ video: true, audio: true }).then((stream) => {
      setStream(stream);
      if (myVideo.current) {
        myVideo.current.srcObject = stream;
      }
    });

    socket.on('me', (id) => {
      setMe(id);
    });

    socket.on('callUser', (data) => {
      setReceivingCall(true);
      setCaller(data.from);
      setName(data.name);
      setCallerSignal(data.signal);
    });
  }, []);

  const callUser = (id) => {
    const peer = new Peer({ initiator: true, trickle: false, stream: stream });

    peer.on('signal', (data) => {
      socket.emit('callUser', { userToCall: id, signalData: data, from: me, name: name });
    });

    peer.on('stream', (stream) => {
      if (userVideo.current) {
        userVideo.current.srcObject = stream;
      }
    });

    socket.on('callAccepted', (signal) => {
      setCallAccepted(true);
      peer.signal(signal);
    });

    connectionRef.current = peer;
  };

  const answerCall = () => {
    setCallAccepted(true);
    const peer = new Peer({ initiator: false, trickle: false, stream: stream });

    peer.on('signal', (data) => {
      socket.emit('answerCall', { signal: data, to: caller });
    });

    peer.on('stream', (stream) => {
      userVideo.current.srcObject = stream;
    });

    peer.signal(callerSignal);
    connectionRef.current = peer;
  };

  const leaveCall = () => {
    setCallEnded(true);
    connectionRef.current.destroy();
  };

  return (
    <div className="container mt-4">
      <h3>Video Call</h3>
      <div className="row">
        <div className="col-md-6">
          <h4>My Video</h4>
          {stream && <video playsInline muted ref={myVideo} autoPlay className="img-fluid rounded" />}
        </div>
        <div className="col-md-6">
          <h4>User's Video</h4>
          {callAccepted && !callEnded && <video playsInline ref={userVideo} autoPlay className="img-fluid rounded" />}
        </div>
      </div>
      <div className="input-group mt-3">
        <input
          type="text"
          className="form-control"
          placeholder="Enter ID to Call"
          value={idToCall}
          onChange={(e) => setIdToCall(e.target.value)}
        />
        <div className="input-group-append">
          {callAccepted && !callEnded ? (
            <button className="btn btn-danger" onClick={leaveCall}>End Call</button>
          ) : (
            <button className="btn btn-primary" onClick={() => callUser(idToCall)}>Call</button>
          )}
        </div>
      </div>
      <div className="mt-3">
        {receivingCall && !callAccepted && (
          <div className="text-center">
            <h5>{name} is calling...</h5>
            <button className="btn btn-success" onClick={answerCall}>Answer</button>
          </div>
        )}
      </div>
    </div>
  );
}

export default App;
